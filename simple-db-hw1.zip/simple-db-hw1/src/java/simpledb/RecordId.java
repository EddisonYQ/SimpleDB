package simpledb;

import java.io.Serializable;

/**
 * A RecordId is a reference to a specific tuple on a specific page of a
 * specific table.
 */
public class RecordId implements Serializable {
	
	// look at the constructor to identify class attributes
	private PageId pid;
	private int tupleno;
    private static final long serialVersionUID = 1L;

    /**
     * Creates a new RecordId referring to the specified PageId and tuple
     * number.
     * 
     * @param pid
     *            the pageid of the page on which the tuple resides
     * @param tupleno
     *            the tuple number within the page.
     */
    public RecordId(PageId pid, int tupleno) {
        // some code goes here
    	this.pid = pid;
    	this.tupleno = tupleno;
    }

    /**
     * @return the tuple number this RecordId references.
     */
    public int getTupleNumber() {
        // some code goes here
        return tupleno;
    }

    /**
     * @return the page id this RecordId references.
     */
    public PageId getPageId() {
        // some code goes here
        return pid;
    }

    /**
     * Two RecordId objects are considered equal if they represent the same
     * tuple.
     * 
     * @return True if this and o represent the same tuple
     */
    @Override
    public boolean equals(Object o) {
        // some code goes here
    	// check o type first. Return true if pageid and tupleNo are equal
    	
    	if(o instanceof RecordId){
    		RecordId instanceOfRecordId = (RecordId) o;
    		boolean pageIdIsEqual = instanceOfRecordId.getPageId().equals(this.getPageId());
    		boolean tupleNoIsEqual = instanceOfRecordId.getTupleNumber() == this.getTupleNumber();
    		if((pageIdIsEqual) && (tupleNoIsEqual))
    			return true;
    	}
    	
    	return false;
	

    }

    /**
     * You should implement the hashCode() so that two equal RecordId instances
     * (with respect to equals()) have the same hashCode().
     * 
     * @return An int that is the same for equal RecordId objects.
     */
    // here we can just call the integer class parser 
    // so we can get the string, and then from the string we get teh attribute's hash code
    @Override
    public int hashCode() {
        // some code goes here
    	int hashCode = 
    			Integer.parseInt(String.valueOf(this.getPageId().hashCode()) + 
    					String.valueOf(this.tupleno));
		
    	return hashCode;
    }

}
